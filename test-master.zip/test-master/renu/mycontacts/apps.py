from django.apps import AppConfig


class MycontactsConfig(AppConfig):
    name = 'mycontacts'
