from django.shortcuts import render
from django.http import HttpResponse
import operator

# Create your views here.

def contacts(requests):
    return HttpResponse('500 contacts in my phone')
