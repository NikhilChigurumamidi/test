from django.apps import AppConfig


class WordcConfig(AppConfig):
    name = 'wordc'
